// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// [Mechanism] : breadcrumb address band
//
//	| Computer |    C:    |  Folder  |
//	|    #0    |    #1    |    #2    |




#define n_oc_path_zero( p ) n_memory_zero( p, sizeof( n_oc_path ) )

n_bool
n_oc_path_error( const n_oc_path *p )
{

	if ( p == NULL ) { return n_true; }

	if ( p->bmp  == NULL ) { return n_true; }
	if ( p->fade == NULL ) { return n_true; }


	return n_false;
}

void
n_oc_path_exit( n_oc_path *p )
{

	if ( p == NULL ) { return; }


	// [!] : bitmaps

	int i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->          bmp[ i ] );
		n_bmp_free( &p->clickable_bmp[ i ] );

		i++;

	}

	n_memory_free( p->          bmp );
	n_memory_free( p->clickable_bmp );


	// [!] : list

	n_vector_free( &p->name );


	// [!] : navigation

	n_memory_free( p->fade );


	// [!] : cache

	i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->cache_bmp[ i ] );

		i++;

	}

	n_memory_free( p->cache_bmp     );
	n_memory_free( p->cache_is_init );
	n_memory_free( p->cache_onoff   );
	n_memory_free( p->cache_percent );
	n_memory_free( p->cache_psx     );
	n_memory_free( p->cache_psy     );
	n_memory_free( p->cache_color   );


	n_oc_path_zero( p );


	return;
}

void
n_oc_path_on_resize( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		i++;

	}


	return;
}

void
n_oc_path_cache_reset( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }


	int i = 0;
	while( 1 )
	{

		if ( i >= p->count ) { break; }

		p->cache_is_init[ i ] = n_false;
		p->cache_onoff  [ i ] = n_false;

		n_bmp_free( &p->cache_bmp[ i ] );

		i++;

	}


	return;
}

void
n_oc_path_style_init( n_oc_path *p )
{

	if ( p == NULL ) { return; }


	p->gdi.sx                 = game.sx;
	p->gdi.sy                 = oc.unit_path;
	p->gdi.scale              = N_GDI_SCALE_AUTO;
	p->gdi.style              = 0;
	p->gdi.align              = 0;

	if ( n_win_darkmode_onoff )
	{
		p->gdi.base_color_bg = n_bmp_white_invisible;
	} else {
		p->gdi.base_color_bg = n_bmp_alpha_invisible_pixel( oc_color.path_bg );
	}

	p->gdi.base_color_fg      = 0;
	p->gdi.base_style         = N_GDI_BASE_SOLID;

	p->gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	p->gdi.icon               = n_posix_literal( "" );
	p->gdi.icon_index         = 0;
	p->gdi.icon_style         = N_GDI_ICON_DEFAULT;

	p->gdi.text               = n_posix_literal( "" );
	p->gdi.text_font          = n_oc_font_name;
	p->gdi.text_size          = n_oc_font_size;
	p->gdi.text_color_main    = oc_color.path_text;
	p->gdi.text_color_contour = oc_color.path_bg;
	p->gdi.text_style         = n_oc_font_smooth;
	p->gdi.text_fxsize1       = 0;
	p->gdi.text_fxsize2       = 0;


	if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
	{

		p->gdi.frame_style = N_GDI_FRAME_TRANS;

	} else
	if ( oc.style == N_ORANGECAT_STYLE_LUNA )
	{

		p->gdi.frame_style = N_GDI_FRAME_TRANS;

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AERO )
	{

		p->gdi.text_style         = n_oc_font_smooth | N_GDI_TEXT_CONTOUR | N_GDI_TEXT_BOLD;
		p->gdi.text_color_main    = n_bmp_white;
		p->gdi.text_color_contour = n_bmp_blend_pixel( oc_color.path_bg, N_ORANGECAT_COLOR_BLACK, 0.5 );
		p->gdi.text_fxsize2       = 2;

		if ( p->gdi.text_style & N_GDI_TEXT_CLEAR )
		{
			p->gdi.text_style = p->gdi.text_style & ~N_GDI_TEXT_CLEAR;
			p->gdi.text_style = p->gdi.text_style |  N_GDI_TEXT_SMOOTH;
		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{

		p->gdi.frame_style  = N_GDI_FRAME_TRANS;

	} else
	if ( oc.style == N_ORANGECAT_STYLE_FLUENT )
	{

		p->gdi.frame_style   = N_GDI_FRAME_TRANS;
		p->gdi.text_style    = n_oc_font_smooth | N_GDI_TEXT_BOLD | N_GDI_TEXT_SMOOTH;

		if ( n_win_darkmode_onoff )
		{
			//p->gdi.base_color_bg = n_bmp_argb( 0, 222,222,222 );
		} else {
			p->gdi.base_color_bg = n_bmp_argb( 0, 111,111,111 );
		}

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{

		if ( n_win_darkmode_onoff )
		{
			p->gdi.base_color_bg      = n_bmp_black_invisible;
			p->gdi.text_color_main    = n_bmp_white;
			p->gdi.text_style         = n_oc_font_smooth | N_GDI_TEXT_CONTOUR_FOG;
			p->gdi.text_color_contour = n_bmp_black;
			p->gdi.text_fxsize1       = oc.unit_scal * 2;
			p->gdi.text_fxsize2       = oc.unit_scal * 2;
		} else {
			p->gdi.text_color_main = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_text, 0.75 );
		}

	}


	return;
}

void
n_oc_path_init( n_oc_path *p )
{

	n_oc_path_exit( p );

	if ( p == NULL ) { return; }


	// Phase 1 : template

	n_oc_path_style_init( p );


	// Phase 2 : list

	p->count         = 1 + n_string_path_split( oc.main, NULL, 0 );
	p->bmp           = n_memory_new( sizeof( n_bmp ) * p->count );
	p->clickable_bmp = n_memory_new( sizeof( n_bmp ) * p->count );

	n_memory_zero( p->          bmp, sizeof( n_bmp ) * p->count );
	n_memory_zero( p->clickable_bmp, sizeof( n_bmp ) * p->count );

	p->clickable_color_bg = N_ORANGECAT_COLOR_BLACK;
	p->clickable_color_fg = n_bmp_white;


	{

		n_vector_new( &p->name );

		int i = 0;
		while( 1 )
		{

			if ( i == 0 )
			{
				n_vector_add( &p->name, i, N_ORANGECAT_COMPUTER );
			} else {
				n_posix_char *str = n_string_path_split_new( oc.main, i - 1 );
				n_string_path_split( oc.main, str, i - 1 );
//n_posix_debug_literal( "%s\n%s", oc.main, str );
				n_vector_add_fast( &p->name, i, str );
			}

			i++;
			if ( i >= p->count ) { break; }
		}

	}


	// Phase 3 : navigation

	p->focus = p->hover = p->press = N_ORANGECAT_NOTHING;
	p->fade  = n_memory_new( sizeof( n_bmp_fade ) * p->count );

	oc.is_input = n_false;


	// Phase 4 : cache

	p->cache_is_init = n_memory_new( sizeof( n_bool ) * p->count );
	p->cache_onoff   = n_memory_new( sizeof( n_bool ) * p->count );
	p->cache_bmp     = n_memory_new( sizeof( n_bmp  ) * p->count );
	p->cache_percent = n_memory_new( sizeof( n_bool ) * p->count );
	p->cache_psx     = n_memory_new( sizeof( int    ) * p->count );
	p->cache_psy     = n_memory_new( sizeof( int    ) * p->count );
	p->cache_color   = n_memory_new( sizeof( u32    ) * p->count );

	n_memory_zero( p->cache_is_init, sizeof( n_bool ) * p->count );
	n_memory_zero( p->cache_onoff,   sizeof( n_bool ) * p->count );
	n_memory_zero( p->cache_bmp,     sizeof( n_bmp  ) * p->count );
	n_memory_zero( p->cache_percent, sizeof( n_bool ) * p->count );
	n_memory_zero( p->cache_psx,     sizeof( int    ) * p->count );
	n_memory_zero( p->cache_psy,     sizeof( int    ) * p->count );
	n_memory_zero( p->cache_color,   sizeof( u32    ) * p->count );


	return;
}

n_bool
n_oc_path_is_computer( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return n_false; }


	if ( p->hover == 0 ) { return n_true; }
	if ( p->focus == 0 ) { return n_true; }


	return n_false;
}

s32
n_oc_path_margin_get( n_oc_path *p, int index )
{

	s32 margin = 0;

	if ( index == ( p->count - 1 ) )
	{
		margin = game.sx - ( p->gdi.sx * p->count );
	}

//n_posix_debug_literal( " %d ", margin );
	return margin;
}

void
n_oc_path_gdi2bitmap( n_oc_path *p, int index, n_bmp *bmp, n_bool fade_onoff )
{

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <=     0 ) { return; }
	if ( p->count <= index ) { return; }


	n_posix_char *lbl = p->name.line[ index ];
	n_posix_char  str[ 1024 ];

	if ( index == 1 )
	{
		n_posix_char *drive_letter = n_string_path_split_new( oc.main, 0 );
		n_posix_char *drive_slash  = n_string_path_slash_new( drive_letter );
		n_posix_char *drive_label  = n_oc_drive_label_get( drive_slash );

		if ( n_string_is_empty( drive_label ) )
		{
			n_posix_sprintf_literal( str, "%s", drive_letter );
		} else {
			n_posix_sprintf_literal( str, "%s (%s)", drive_label, drive_letter );
		}

		n_string_path_free( drive_letter );
		n_string_path_free( drive_slash  );
		n_string_path_free( drive_label  );

		lbl = str;
	}

	p->gdi.text = lbl;


	// [Patch] : for remainder margin

	s32 margin = n_oc_path_margin_get( p, index );


	p->gdi.sx += margin;

	{

		n_bmp *clickable_bmp = &p->clickable_bmp[ index ];


		s32 min_sx = p->gdi.sy;//( p->gdi.sx / p->count ) + margin;

		if ( oc.style == N_ORANGECAT_STYLE_AQUA )
		{

			s32 gdi_sx = p->gdi.sx;
			p->gdi.sx = n_posix_max_s32( min_sx, p->gdi.sx - p->gdi.sy );

			if ( p->gdi.sx == min_sx )
			{

				n_bmp_new( bmp, p->gdi.sx,p->gdi.sy );
				n_bmp_flush( bmp, oc_color.bg );

				p->gdi.sx = gdi_sx;
				n_bmp_resizer( bmp, p->gdi.sx,p->gdi.sy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

			} else {

				n_gdi_bmp( &p->gdi, bmp );
				n_bmp_fill( bmp, 0,0, oc_color.bg );

				p->gdi.sx = gdi_sx;
				n_bmp_resizer( bmp, p->gdi.sx,p->gdi.sy, n_bmp_white_invisible, N_BMP_RESIZER_CENTER );

			}

		} else {

			n_gdi_bmp( &p->gdi, bmp );
			//n_bmp_fill( bmp, 0,0, oc_color.bg );

		}


		s32 sx = n_posix_max_s32(    min_sx, N_BMP_SX( bmp ) );
		s32 sy = n_posix_max_s32( p->gdi.sy, N_BMP_SY( bmp ) );

		n_bmp_new_fast( clickable_bmp, sx,sy );

		if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
		{

			int frame  = 1 * oc.unit_scal;
			int frames = frame * 2;

			n_bmp_flush( clickable_bmp,                                   p->clickable_color_bg );
			n_bmp_box  ( clickable_bmp, frame,frame, sx-frames,sy-frames, p->clickable_color_fg );

		} else
		if ( oc.style == N_ORANGECAT_STYLE_LUNA )
		{

			p->gdi.frame_round = 3 * oc.unit_scal;
			p->gdi.frame_size  = 1 * oc.unit_scal;

			int r  = p->gdi.frame_round;
			int sz = p->gdi.frame_size;

			n_bmp_flush     ( clickable_bmp,        p->clickable_color_fg );
			n_bmp_cornermask( clickable_bmp, r, sz, p->clickable_color_bg );

		} else
		if ( oc.style == N_ORANGECAT_STYLE_AERO )
		{

			int frame  = 1 * oc.unit_scal;
			int frames = frame * 2;

			n_bmp_flush( clickable_bmp,                                   p->clickable_color_bg );
			n_bmp_box  ( clickable_bmp, frame,frame, sx-frames,sy-frames, p->clickable_color_fg );

		} else
		if ( oc.style == N_ORANGECAT_STYLE_8 )
		{

			int frame  = 1 * oc.unit_scal;
			int frames = frame * 2;

			n_bmp_flush( clickable_bmp,                                   p->clickable_color_bg );
			n_bmp_box  ( clickable_bmp, frame,frame, sx-frames,sy-frames, p->clickable_color_fg );

		} else
		if ( oc.style == N_ORANGECAT_STYLE_FLUENT )
		{

			//

		} else
		if ( oc.style == N_ORANGECAT_STYLE_AQUA )
		{

			int r  = -100;
			int sz = 2 * oc.unit_scal;

			n_bmp_flush     ( clickable_bmp,        p->clickable_color_fg );
			n_bmp_cornermask( clickable_bmp, r, sz, p->clickable_color_bg );
//n_bmp_save_literal( clickable_bmp, "ret.bmp" );
		}


//n_posix_sprintf_literal( name, "%d.bmp", index );
//n_bmp_save( bmp, name );

	}

	p->gdi.sx -= margin;


	if ( fade_onoff )
	{
		n_bmp_fade_init( &p->fade[ index ], oc_color.path_bg );
	}


	return;
}

void
n_oc_path_aqua_dropshadow( n_oc_path *p, s32 x, s32 y, s32 sx, s32 sy, n_bmp *bmp )
{
/*
	// [!] : approach #1 : faster : not accurate

	n_bmp shadow; n_bmp_zero( &shadow ); n_bmp_1st_fast( &shadow, sx,sy );
	n_bmp_flush( &shadow, oc_color.bg );

	//u32 color_0 = n_bmp_rgb( 255,0,0 );
	//u32 color_1 = n_bmp_rgb( 0,255,0 );
	//u32 color_2 = n_bmp_rgb( 0,0,255 );
	u32 color_0 = n_bmp_blend_pixel( oc_color.bg, N_ORANGECAT_COLOR_BLACK, 0.50 );
	u32 color_1 = n_bmp_blend_pixel( oc_color.bg, N_ORANGECAT_COLOR_BLACK, 0.75 );
	u32 color_2 = n_bmp_blend_pixel( oc_color.bg, N_ORANGECAT_COLOR_BLACK, 1.00 );
	n_bmp_roundrect_ratio( &shadow, 0,2,sx,sy-0, color_0, 100 );
	n_bmp_roundrect_ratio( &shadow, 0,2,sx,sy-2, color_1, 100 );
	n_bmp_roundrect_ratio( &shadow, 0,2,sx,sy-3, color_2, 100 );

	if ( bmp == NULL )
	{
		n_bmp_blendcopy( &shadow, &game.bmp, 0,0,sx,sy, x,y, 0.75 );
	} else {
		n_bmp_flush_blendcopy( &shadow, bmp, 0.75 );
	}

	n_bmp_free( &shadow );
*/

	// [!] : approach #2 : slower : more accurate

	s32 o  = oc.unit_scal;
	s32 oo = o * 2;

	sx += 2 * o;

	n_bmp shadow; n_bmp_zero( &shadow ); n_bmp_1st_fast( &shadow, sx,sy );
	n_bmp_flush( &shadow, oc_color.bg );

	u32 color = n_bmp_blend_pixel( oc_color.bg, oc_color.path_bg, 1.00 );
	n_bmp_roundrect_ratio( &shadow, o,o,sx-oo,sy-oo, color, 100 );

	int i = 0;
	while( 1 )
	{
		n_bmp_flush_antialias( &shadow, 1.0 );
		n_bmp_flush_antialias( &shadow, 1.0 );
		n_bmp_flush_antialias( &shadow, 1.0 );

		i++;
		if ( i >= o ) { break; }
	}

//n_bmp_save_literal( &shadow, "ret.bmp" );

	if ( bmp == NULL )
	{
		n_bmp_blendcopy( &shadow, &game.bmp, 0,0,sx,sy, x-o,y+o, 0.7 );
	} else {
		n_bmp_blendcopy( &shadow,       bmp, 0,0,sx,sy, 0-o,0+o, 0.7 );
	}

	n_bmp_free( &shadow );


	return;
}

static int n_oc_path_draw_single_aqua_forced_on_index = N_ORANGECAT_NOTHING;

void
n_oc_path_draw_single( n_oc_path *p, int index )
{
//return;

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <=     0 ) { return; }
	if ( p->count <= index ) { return; }


	if ( p->fade[ index ].stop ) { return; }


	n_bmp *t = &p->bmp[ index ];
	if ( NULL ==            t   ) { return; }
	if ( NULL == N_BMP_PTR( t ) ) { return; }
//n_bmp_save_literal( t, "ret.bmp" );


	s32 sx = N_BMP_SX( t );
	s32 sy = N_BMP_SY( t ); 
	s32 tx = p->gdi.sx * index;
	s32 ty = 0;


	// Fade Engine

	n_bmp_fade *fade = &p->fade[ index ];

	u32 fg = n_bmp_fade_engine( fade, oc.fade_onoff );
	u32 bg = fade->color_bg;

	double ratio = (double) fade->percent * 0.01;

//n_game_hwndprintf_literal( " %d : %f ", fade->percent, ratio );


	if ( fade->color_bg == oc_color.path_drop )
	{
//n_game_hwndprintf_literal( " ! " );
		fg = n_bmp_blend_pixel( oc_color.path_drop, fg, ratio );
	}


	// Background Eraser

	// [!] : margin will be non-transparent if this n_bmp_box() is used
 
	n_bmp_box( &game.bmp, tx,ty,sx,sy, game.color );


	// Cache

	n_bmp b;

	if (
		( p->cache_is_init[ index ] == n_false        )
		||
		( p->cache_percent[ index ] != 100            )
		||
		( p->cache_psx    [ index ] != sx             )
		||
		( p->cache_psy    [ index ] != sy             )
		||
		( p->cache_color  [ index ] != fade->color_fg )
	)
	{
//n_game_hwndprintf_literal( " Cache : Off " );
		p->cache_is_init[ index ] = n_true;
		p->cache_onoff  [ index ] = n_false;
		n_bmp_zero( &b ); n_bmp_1st_fast( &b, sx,sy );
	} else {
//n_game_hwndprintf_literal( " Cache : On " );
		p->cache_onoff  [ index ] = n_true;
		n_bmp_alias( &p->cache_bmp[ index ], &b );
	}

	p->cache_percent[ index ] = fade->percent;
	p->cache_psx    [ index ] = sx;
	p->cache_psy    [ index ] = sy;
	p->cache_color  [ index ] = fade->color_fg;

//if ( index == 3 ) { n_game_hwndprintf_literal( " %d ", fade->percent ); }


	n_bool press_onoff = ( p->press == index );


	// Theme Engine

	s32 u = oc.unit_scal;

	if ( oc.style == N_ORANGECAT_STYLE_CLASSIC )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : Temp canvas

			n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp ); n_bmp_1st_fast( &bmp_tmp, sx,sy );


			// [!] : Base

			n_bmp_flush( &b, n_bmp_white_invisible );


			// [!] : Frame

			n_bmp_flush( &bmp_tmp, n_bmp_white_invisible );

			n_bmp_box( &bmp_tmp, (u*1),(u*1), sx-(u*2),sy-(u*2), oc_color.path_frame1 );
			n_bmp_box( &bmp_tmp, (u*2),(u*2), sx-(u*4),sy-(u*4), oc_color.path_frame2 );
			n_bmp_box( &bmp_tmp, (u*3),(u*3), sx-(u*6),sy-(u*6), oc_color.path_bg     );

			n_bmp_flush_transcopy( &bmp_tmp, &b );


			// [!] : Text

			{

				s32 xx = 0;
				s32 yy = 0;

				if ( press_onoff ) { xx += u; yy += u; }

				n_bmp_transcopy( t, &b, 0,0,sx,sy, xx,yy );

			}
//n_bmp_save_literal( &bmp_tmp, "ret.bmp" );


			// [!] : Highlight frame

			n_bmp_flush( &bmp_tmp, n_bmp_white_invisible );


			n_bool frame_onoff = n_false;
			n_bool frame_ratio = 0.0;

			if (
				( fade->color_fg == oc_color.path_hover )
				||
				( fade->color_fg == oc_color.path_drop  )
				||
				( fade->color_fg == oc_color.path_press )
			)
			{
				frame_onoff = n_true;
				frame_ratio = 1.0 - ratio;
			} else
			if (
				( fade->color_bg == oc_color.path_hover )
				||
				( fade->color_bg == oc_color.path_drop  )
				||
				( fade->color_bg == oc_color.path_press )
			)
			{
				frame_onoff = n_true;
				frame_ratio = ratio;
			}

			if ( frame_onoff )
			{

				n_bmp_box( &bmp_tmp, (u*2),(u*2), sx-(u*4),sy-(u*4),                    fg );
				n_bmp_box( &bmp_tmp, (u*3),(u*3), sx-(u*6),sy-(u*6), n_bmp_white_invisible );

				n_bmp_flush_blendcopy( &bmp_tmp, &b, frame_ratio );

			}


			// [!] : Temp canvas

			n_bmp_free( &bmp_tmp );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &b );
			}


			// [!] : Cache

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );

		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_LUNA )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : Base : "oc_color.bg" is important under DWM

			n_bmp_flush( &b, oc_color.bg );


			if ( ( n_sysinfo_version_xp() )&&( n_false == n_win_style_is_classic() ) )
			{

				const int  bp = BP_PUSHBUTTON;
				const RECT r  = n_win_rect_set( NULL, 0,0,sx,sy );


				n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
				n_uxtheme_init( &uxtheme, game.hwnd, L"BUTTON" );


				HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( game.hwnd, sx,sy );
//if (bp){}
//if (r.top){}
//if (hdc){}
//n_gdi_doublebuffer_fill( &n_gdi_doublebuffer_32bpp_instance, RGB( 0,200,255 ) );
//n_bmp_flush_fastcopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &b );


				n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st( &bmp, sx,sy );


				int pbs;

				pbs = PBS_NORMAL;
				if ( fade->color_bg == oc_color.path_drop  ) { pbs = PBS_DEFAULTED; } else
				if ( fade->color_bg == oc_color.path_hover ) { pbs = PBS_HOT      ; } else
				if ( fade->color_bg == oc_color.path_press ) { pbs = PBS_PRESSED  ; }
				uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, bp,pbs, &r, NULL );
				n_bmp_flush_fastcopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp );

				pbs = PBS_NORMAL;
				if ( fade->color_fg == oc_color.path_drop  ) { pbs = PBS_DEFAULTED; } else
				if ( fade->color_fg == oc_color.path_hover ) { pbs = PBS_HOT      ; } else
				if ( fade->color_fg == oc_color.path_press ) { pbs = PBS_PRESSED  ; }
				uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, bp,pbs, &r, NULL );
				n_bmp_flush_fastcopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &b );

//n_bmp_save_literal( &bmp, "f.bmp" );
//n_bmp_save_literal( &b  , "t.bmp" );
				n_bmp_flush_blendcopy( &bmp, &b, ratio );


				n_bmp_free_fast( &bmp );


				n_gdi_doublebuffer_32bpp_cleanup( &n_gdi_doublebuffer_32bpp_instance );


				n_posix_char name[ N_UXTHEME_THEMENAME_CCH_MAX ];
				n_uxtheme_themename( &uxtheme, name );
				if ( n_string_is_same_literal( "Zune", name ) )
				{
					n_bmp_alpha_reverse( &b );
				}


				n_uxtheme_exit( &uxtheme, game.hwnd );

			} else
			if ( ( press_onoff )||( fade->color_bg == oc_color.path_press ) )
			{
//n_game_debug_count();
//n_game_hwndprintf_literal( " %d %d ", fade->stop, fade->percent );

				if ( press_onoff == n_false )
				{

					// [!] : Base

					n_bmp bmp_prev; n_bmp_zero( &bmp_prev ); n_bmp_1st( &bmp_prev, sx,sy );

					n_gdi_base_luna_press( &p->gdi, &bmp_prev, oc_color.path_bg, oc.unit_scal );
					n_gdi_base_luna_solid( &p->gdi, &b       , oc_color.path_bg, oc.unit_scal );

					n_bmp_flush_blendcopy( &bmp_prev, &b, ratio );

					n_bmp_free( &bmp_prev );

				} else {

					// [!] : Base

					n_bmp bmp_prev; n_bmp_zero( &bmp_prev ); n_bmp_1st( &bmp_prev, sx,sy );

					n_gdi_base_luna_solid( &p->gdi, &bmp_prev, oc_color.path_bg, oc.unit_scal );
					n_gdi_base_luna_press( &p->gdi, &b       , oc_color.path_bg, oc.unit_scal );

					n_bmp_flush_blendcopy( &bmp_prev, &b, ratio );

					n_bmp_free( &bmp_prev );

				}

				n_gdi_frame_roundframe_luna( &p->gdi, &b, sx,sy, 0, oc_color.path_luna, oc_color.bg, oc_color.path_luna, oc_color.bg, oc.unit_scal );

			} else {

				// [!] : Base

				n_gdi_base_luna_solid( &p->gdi, &b, oc_color.path_bg, oc.unit_scal );
				n_gdi_frame_roundframe_luna( &p->gdi, &b, sx,sy, 0, oc_color.path_luna, oc_color.bg, oc_color.path_luna, oc_color.bg, oc.unit_scal );


				// [!] : Highlight frame
//n_game_hwndprintf_literal( " %x %x ", fade->color_fg, fade->color_bg );

				if ( ( fade->color_fg == oc_color.path_bg )&&( fade->percent == 100 ) )
				{

					//

				} else {

					n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp ); n_bmp_1st_fast( &bmp_tmp, sx,sy );
					n_bmp_flush( &bmp_tmp, n_bmp_white_invisible );

					n_gdi_frame_roundframe_luna( &p->gdi, &bmp_tmp, sx,sy, p->gdi.frame_size * 2, fg, oc_color.bg, oc_color.path_luna, oc_color.bg, oc.unit_scal );

					n_bmp_flush_transcopy( &bmp_tmp, &b );

					n_bmp_free( &bmp_tmp );

				}

			}


			// [!] : Text

			n_bmp_transcopy( t, &b, (u*2),(u*2), sx-(u*4),sy-(u*4), (u*2),(u*2) );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &b );
			}


			// [!] : Cache

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );
//n_bmp_save_literal( &b, "ret.bmp" );

		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AERO )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : Base

			n_bmp_flush( &b, n_bmp_white_invisible );


			// [!] : Background

			bg = oc_color.path_bg;

			if ( press_onoff )
			{
				//fg = n_bmp_blend_pixel( fg, n_bmp_rgb( 0,200,255 ), ratio );
				fg = n_bmp_blend_pixel( fg, oc_color.path_press, ratio );
			}

			int option = N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING;
			n_bmp_gradient( &b, (u*1),(u*1), sx-(u*2),sy-(u*2), fg,bg, option );

			u32 color_frame = n_bmp_blend_pixel( fg, N_ORANGECAT_COLOR_BLACK, 0.125 );
			n_oc_lineframe( &b, (u*1),(u*1), sx-(u*2),sy-(u*2), color_frame );


			// [!] : Text

			{

				s32 xx = 0;
				s32 yy = 0;

				if ( press_onoff ) { yy += u; }

				n_bmp_transcopy( t, &b, 0,0,sx,sy, xx,yy );

			}


			// [!] : Highlight

			n_bmp_mixer( &b, 0+(u*1),0+(u*1),sx-(u*2),sy/2, n_bmp_white, 0.2 );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &b );
			}


			// [!] : Cache

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );

		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_8 )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : Temp canvas

			n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp ); n_bmp_1st_fast( &bmp_tmp, sx,sy );
			n_bmp_flush( &bmp_tmp, n_bmp_white_invisible );


			// [!] : Base

			n_bmp_flush( &b, n_bmp_white_invisible );


			// [!] : Frame


			u32 frame_color = fg;

			if ( fade->color_fg == oc_color.path_bg )
			{
				frame_color = n_bmp_blend_pixel( fg, oc_color.path_frame1, ratio );
			} else
			if ( fade->color_bg == oc_color.path_bg )
			{
				frame_color = n_bmp_blend_pixel( oc_color.path_frame1, fg, ratio );
			}


			// [!] : Background

			u32    bg_color = oc_color.path_bg;
			u32 light_color = oc_color.path_frame2;

			u32 hover_color = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_hover, 0.25 );
			u32  drop_color = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_drop , 0.25 );
			u32 press_color = n_bmp_blend_pixel( oc_color.path_bg, oc_color.path_press, 0.25 );
			u32 layer_color = n_bmp_blend_pixel( light_color,      hover_color,         0.33 );
//n_game_hwndprintf_literal( " %08x %08x ", fade->color_fg, fade->color_bg );

			if ( fade->color_fg == oc_color.path_hover )
			{
				hover_color = layer_color;
				   bg_color = n_bmp_blend_pixel( bg_color, hover_color, ratio );
			} else
			if ( fade->color_fg == oc_color.path_drop  )
			{
				   bg_color = n_bmp_blend_pixel( bg_color,  drop_color, ratio );
			} else
			if ( fade->color_fg == oc_color.path_press )
			{
				   bg_color = layer_color;
				   bg_color = n_bmp_blend_pixel( bg_color, press_color, ratio );
			} else
			if ( fade->color_bg == oc_color.path_hover )
			{
				hover_color = layer_color;
				   bg_color = n_bmp_blend_pixel( hover_color, bg_color, ratio );
			} else
			if ( fade->color_bg == oc_color.path_drop  )
			{
				   bg_color = n_bmp_blend_pixel(  drop_color, bg_color, ratio );
			} else
			if ( fade->color_bg == oc_color.path_press )
			{ 
				   bg_color = n_bmp_blend_pixel( press_color, bg_color, ratio );
			}


			n_bmp_box( &bmp_tmp, (u*1),(u*1), sx-(u*2),sy-(u*2), frame_color );

			u32 gradient_color;
			if ( n_win_darkmode_onoff )
			{
				u32 matte_black = n_bmp_rgb( 100,100,100 );
				gradient_color = n_bmp_blend_pixel( bg_color, matte_black, 0.5 );
			} else {
				gradient_color = n_bmp_blend_pixel( bg_color, n_bmp_white, 0.5 );
			}
			n_bmp_gradient( &bmp_tmp, (u*2),(u*2), sx-(u*4),sy-(u*4), gradient_color, bg_color, N_BMP_GRADIENT_VERTICAL );

			n_bmp_flush_transcopy( &bmp_tmp, &b );


			// [!] : Text

			{

				s32 xx = 0;
				s32 yy = 0;

				// [!] : Nonnon Original Behavior
				if ( press_onoff ) { yy = u; }

				n_bmp_transcopy( t, &b, (u*2)-xx,(u*2)-yy, sx-(u*4),sy-(u*4), (u*2),(u*2) );

			}


			// [!] : Temp canvas

			n_bmp_free( &bmp_tmp );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &b );
			}


			// [!] : Cache

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );

		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_FLUENT )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : Base

			if ( n_win_darkmode_onoff )
			{
				n_bmp_flush( &b, n_bmp_black_invisible );
			} else {
				n_bmp_flush( &b, n_bmp_white_invisible );
			}


			// [!] : Main

			s32 round = n_win_fluent_ui_round_param();

			n_bmp_roundrect_pixel( &b, (u*1),(u*1), sx-(u*2),sy-(u*2), fg, round );


			// [!] : Text

			{

				s32 xx = 0;
				s32 yy = 0;

				if ( press_onoff ) { xx += u; yy += u; }

				n_bmp_transcopy( t, &b, 0,0,sx,sy, xx,yy );

			}
//n_bmp_save_literal( &bmp_tmp, "ret.bmp" );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &b );
			}


			// [!] : Cache

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );

		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );

	} else
	if ( oc.style == N_ORANGECAT_STYLE_AQUA )
	{

		if ( p->cache_onoff[ index ] == n_false )
		{

			// [!] : dummy color

			n_bool   hover_onoff = n_false;
			n_bool unhover_onoff = n_false;
			n_bool unpress_onoff = n_false;

			if (
				( n_oc_path_draw_single_aqua_forced_on_index != N_ORANGECAT_NOTHING )
				&&
				( n_oc_path_draw_single_aqua_forced_on_index == index )
			)
			{

				hover_onoff = n_true;
				fg = oc_color.path_bg;

			} else
			if ( fade->color_fg == oc_color.path_hover )
			{

				hover_onoff = n_true;
				fg = oc_color.path_hover;

			} else
			if ( fade->color_bg == oc_color.path_hover )
			{
//n_game_debug_count();
				unhover_onoff = n_true;
				fg = oc_color.path_bg;

			} else
			if ( fade->color_bg == oc_color.path_press )
			{

				unpress_onoff = n_true;
				fg = oc_color.path_bg;

			}

//n_game_hwndprintf_literal( " %x %x : %x ", fade->color_fg, fade->color_bg, oc_color.path_bg );
//n_game_hwndprintf_literal( " %d %d %d ", press_onoff, hover_onoff, unhover_onoff );


			// [!] : Base

			u32 gradient_fg = n_oc_color_aqua_path_keycolor( fg );
			u32 gradient_bg = n_bmp_blend_pixel( fg, N_ORANGECAT_COLOR_BLACK, 0.75 );

			n_bmp bmp_tmp; n_bmp_zero( &bmp_tmp ); n_bmp_1st_fast( &bmp_tmp, sx,sy );


			// [!] : Gradient background

			{

				u32 color_fg = n_bmp_blend_pixel( fg, N_ORANGECAT_COLOR_BLACK, 0.25 );
				u32 color_bg = n_bmp_blend_pixel( fg,             n_bmp_white, 0.75 );

				n_bmp_flush_gradient( &b, color_fg, color_bg, N_BMP_GRADIENT_VERTICAL );

			}

			{

				u32 color_fg = gradient_fg;
				u32 color_bg = gradient_bg;

				int option = N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING;
				n_bmp_flush_gradient( &bmp_tmp, color_fg, color_bg, option );

				n_bmp_flush_blendcopy( &bmp_tmp, &b, 0.5 );

			}


			if ( ( press_onoff )||( unpress_onoff ) )
			{

				u32 color_fg = oc_color.path_press;
				u32 color_bg = gradient_bg;

				int option = N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING;
				n_bmp_flush_gradient( &bmp_tmp, color_fg, color_bg, option );

				double d = n_posix_minmax_double( 0.0, 1.0, ratio );

				if ( press_onoff )
				{
					d = 1.0 - ( d * 0.5 );
				} else {
					d = 0.5 + ( d * 0.5 );
				}
//n_game_hwndprintf_literal( " %f ", d );

				n_bmp_flush_blendcopy( &bmp_tmp, &b, d );

			} else
			if ( ( hover_onoff )||( unhover_onoff ) )
			{

				u32 color_fg = n_bmp_white;
				u32 color_bg = n_bmp_white_invisible;

				int option = N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING;
				n_bmp_flush_gradient( &bmp_tmp, color_fg, color_bg, option );

				double d = n_posix_minmax_double( 0.0, 1.0, ratio );

				if ( hover_onoff )
				{
					d = 1.0 - ( d * 0.5 );
				} else {
					d = 0.5 + ( d * 0.5 );
				}

				n_bmp_flush_blendcopy( &bmp_tmp, &b, d );

			}


			// [!] : Corner mask

			n_bmp_cornermask( &b, -100, 2 * oc.unit_scal, oc_color.bg );


			// [!] : Highlight

			s32 unit     = 4 * oc.unit_scal;
			int half     = sy / 2;
			s32 sugar_sx = n_posix_max_s32( half, sx - ( half * 2 ) + ( unit * 2 ) );
			s32 sugar_sy = half;
			s32 sugar_x  = half - unit;
			s32 sugar_y  = unit;

			if ( sugar_sx == half ) { sugar_x = n_game_centering( sx, sugar_sx ); }

			n_bmp_new_fast( &bmp_tmp, sugar_sx,sugar_sy );
			n_bmp_flush_gradient( &bmp_tmp, n_bmp_white_invisible, n_bmp_white, N_BMP_GRADIENT_VERTICAL );
			n_bmp_flush_mirror( &bmp_tmp, N_BMP_MIRROR_UPSIDE_DOWN );
			n_bmp_cornermask( &bmp_tmp, -100, 0, n_bmp_white_invisible );
			n_bmp_blendcopy( &bmp_tmp, &b, 0,0,sugar_sx,sugar_sy, sugar_x,sugar_y, 0.250 );


			// [!] : Back buffer

			n_bmp_new( &bmp_tmp, sx,sy );
			n_bmp_flush( &bmp_tmp, oc_color.bg );


			// [!] : Drop shadow #1

			if ( n_false == oc.dwm_onoff )
			{
				n_oc_path_aqua_dropshadow( p, tx,ty,sx,sy, &bmp_tmp );
			}

			n_bmp_flush_transcopy( &b, &bmp_tmp );

			if ( n_false == oc.dwm_onoff )
			{
				n_bmp_alpha_visible( &bmp_tmp );
			}


			// [!] : Text

			n_bmp_fill( t, N_BMP_SX( t ) / 2,0, n_bmp_alpha_invisible_pixel( oc_color.path_bg ) );
			n_bmp_flush_transcopy( t, &bmp_tmp );
//n_bmp_save_literal( t, "ret.bmp" );


			// [!] : Transparency

			if ( oc.dwm_onoff )
			{
				n_oc_color_aero_alpha( &bmp_tmp );
			}


			// [!] : Cache

			n_bmp_free_fast( &b );
			n_bmp_alias( &bmp_tmp, &b );

			n_bmp_free_fast( &p->cache_bmp[ index ] );
			n_bmp_alias( &b, &p->cache_bmp[ index ] );

		}


		// [!] : Drop shadow #2

		if ( oc.dwm_onoff )
		{
			n_oc_path_aqua_dropshadow( p, tx,ty,sx,sy, NULL );
		}


		// [!] : Draw

		n_bmp_transcopy( &b, &game.bmp, 0,0,sx,sy, tx,ty );
/*
n_bmp save; n_bmp_zero( &save ); n_bmp_new_fast( &save, sx,sy );
n_bmp_fastcopy( &game.bmp, &save, tx,ty,sx,sy, 0,0 );
n_bmp_save_literal( &save, "ret.bmp" );
n_bmp_free( &save );
*/

	}


	game.simplemenu_refresh = n_true;

	n_game_refresh_on();


	return;
}

void
n_oc_path_erase( n_oc_path *p )
{

	s32  x = 0;
	s32  y = 0;
	s32 sx = game.sx;
	s32 sy = oc.unit_path;

	n_bmp_box( &game.bmp, x,y,sx,sy, game.color );


	return;
}

int
n_oc_path_index2path_cch( n_oc_path *p, int index )
{

	if ( n_oc_path_error( p ) ) { return 0; }

	if ( p->count <=     0 ) { return 0; }
	if ( p->count <= index ) { return 0; }


	int ret = 0;

	if ( index == 0 )
	{

		ret = n_posix_strlen( p->name.line[ index ] );

	} else {

		int i = 1;
		while( 1 )
		{

			if ( i == 1 )
			{
				ret  = n_posix_strlen( p->name.line[ index ] ) + n_posix_strlen( N_STRING_BSLASH );
			} else {
				ret += n_posix_strlen( p->name.line[ i     ] ) + n_posix_strlen( N_STRING_BSLASH );
			}


			i++;
			if ( i > index ) { break; }
		}

	}


	return ret;
}

void
n_oc_path_index2path( n_oc_path *p, int index, n_posix_char *name )
{

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <=     0 ) { return; }
	if ( p->count <= index ) { return; }


	if ( index == 0 )
	{

		n_string_copy( p->name.line[ index ], name );

	} else {

		int i = 1;
		while( 1 )
		{

			if ( i == 1 )
			{
				n_string_copy( p->name.line[ i ], name );
				n_posix_strcat( name, N_STRING_BSLASH );
			} else {
				n_string_path_make( name, p->name.line[ i ], name );
			}


			i++;
			if ( i > index ) { break; }
		}

	}


	return;
}

n_posix_char*
n_oc_path_index2path_new( n_oc_path *p, int index )
{

	// [!] : you need to n_string_path_free() a returned variable

	int           cch = n_oc_path_index2path_cch( p, index );
	n_posix_char *ret = n_string_path_new( cch );


	n_oc_path_index2path( p, index, ret );


	return ret;
}

void
n_oc_path_bitmap_make( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }


	p->gdi.sx = game.sx / p->count;


	int i = 0;
	while( 1 )
	{//break;

		// Delayed Loading

		if ( NULL == N_BMP_PTR( &p->bmp[ i ] ) )
		{
			n_oc_path_gdi2bitmap( p, i, &p->bmp[ i ], n_true );
		}


		i++;
		if ( i >= p->count ) { break; }
	}


	return;
}

void
n_oc_path_draw( n_oc_path *p )
{
//return;

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }

//n_posix_debug_literal( "%d", p->count ); return;


	//n_oc_path_erase( p );

	p->gdi.sx = game.sx / p->count;


	int i = 0;
	while( 1 )
	{//break;


		// Delayed Loading

		if ( NULL == N_BMP_PTR( &p->bmp[ i ] ) )
		{
//n_game_debug_count();
			n_oc_path_gdi2bitmap( p, i, &p->bmp[ i ], n_true );
		}

		n_bmp_fade_redraw( &p->fade[ i ] );

		n_oc_path_draw_single( p, i );


		i++;
		if ( i >= p->count ) { break; }
	}


	return;
}

void
n_oc_path_fade( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }


	n_posix_bool redraw = n_posix_false;


	int i = 0;
	while( 1 )
	{//break;

		if (
			( n_false == n_oc_path_is_computer( p ) )
			&&
			( p->hover == i )
			&&
			( n_false == n_oc_is_desktop_selection() )
		)
		{
			n_bool find_onoff = n_win_message_send( oc.view_hwnd, oc.msg_find_onoff, 0,0 );
			if ( ( oc.is_external_dnd )&&( find_onoff == n_false ) )
			{
				n_bmp_fade_go( &p->fade[ i ], oc_color.path_drop );
			}
		} else
		if ( p->focus == i )
		{
			//
		} else
		if ( p->press == i )
		{
			//
		} else
		if ( p->hover == i )
		{
			//
		} else {
			redraw = n_posix_true;
			n_bmp_fade_go( &p->fade[ i ], oc_color.path_bg );
		}

		n_oc_path_draw_single( p, i );


		i++;
		if ( i >= p->count ) { break; }
	}


	if ( redraw )
	{
		n_game_refresh_on();
	}


	return;
}

n_bool
n_oc_path_hover_is_computer_global( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return n_false; }


	if ( p->hover == 0 ) { return n_true; }


	n_bool hover_onoff = n_false;


	n_bool is_oc = n_win_message_send( oc.view_hwnd, oc.msg_is_oc, 0,0 );

	if ( is_oc )
	{

		s32 tx = 0;
		s32 ty = 0;
		s32 sx = n_win_message_send( oc.view_hwnd, oc.msg_path_sx, 0,0 );
		s32 sy = n_win_message_send( oc.view_hwnd, oc.msg_path_sy, 0,0 );

		hover_onoff = n_win_is_hovered_offset( oc.view_hwnd, tx, ty, sx, sy );

	}


	return hover_onoff;
}

void
n_oc_path_go( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }


	int index = p->hover;
	if ( p->focus != N_ORANGECAT_NOTHING ) { index = p->focus; }


	n_posix_char *name;

	if ( n_oc_path_is_computer( p ) )
	{
		name = n_string_path_carboncopy( N_ORANGECAT_COMPUTER );
	} else {
		name = n_oc_path_index2path_new( p, index );
	}


	int maxim = p->count - 1 - 1;
	if ( index <= maxim )
	{
//n_posix_debug_literal( " ! " );

		n_string_path_free( oc.head );
		oc.head = n_string_path_carboncopy( oc.main );

//n_posix_debug_literal( " %d %d ", maxim, index );
		int i = 0;
		while( 1 )
		{//break;

			if ( i >= ( maxim - index ) ) { break; }

			n_posix_char *s = n_string_path_carboncopy( oc.head );

			n_string_path_free( oc.head );
			oc.head = n_string_path_upperfolder_new( s );

			n_string_free( s );

			i++;

		}

		if ( index == 0 )
		{
			n_posix_char *s = n_string_path_slash_new( oc.head );
			n_string_path_free( oc.head );
			oc.head = s;
		}

	}
//n_posix_debug_literal( "%s\n%s", oc.main, oc.head );

//n_posix_debug_literal( "%s", name );
	n_oc_navigate( name );


	n_string_path_free( name );


	return;
}

void
n_oc_path_on_click( n_oc_path *p )
{

	if ( n_oc_path_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }


	if ( oc.scrollbar.drag_onoff ) { return; }


//n_game_hwndprintf_literal( " %d ", item.drag );
	if ( item.drag == N_ORANGECAT_DRAG_SCROLL ) { return; }


	// Phase 1 : Collision

	{

		n_bool hover_onoff = n_false;

		s32 tx = 0;
		s32 ty = 0;

		int i = 0;
		while( 1 )
		{//break;

			n_bmp *b  = &p->          bmp[ i ];
			n_bmp *c  = &p->clickable_bmp[ i ];

			if (
				( NULL != N_BMP_PTR( b ) )
				&&
				( NULL != N_BMP_PTR( c ) )
			)
			{

				s32 sx = N_BMP_SX( b );
				s32 sy = N_BMP_SY( b ); 

				hover_onoff = n_win_is_hovered_offset( game.hwnd, tx, ty, sx, sy );
				if ( hover_onoff )
				{
//break;
					s32 x = oc.cursor_x - tx;
					s32 y = oc.cursor_y;
					u32 color = p->clickable_color_fg; n_bmp_ptr_get( c, x,y, &color );
//n_game_hwndprintf_literal( " %08x ", color );

					if ( color == p->clickable_color_bg )
					{
						hover_onoff = n_false;
					}

					break;
				}

				tx += sx;

			}

			i++;
			if ( i >= p->count ) { i = N_ORANGECAT_NOTHING; break; }
		}
//n_game_hwndprintf_literal( " %d ", p->hover );

		if ( hover_onoff )
		{
			p->hover = i;
		} else {
			p->hover = N_ORANGECAT_NOTHING;
		}


		if ( oc.view_hover != N_ORANGECAT_VIEW_HOVER_PATH )
		{
			p->hover = N_ORANGECAT_NOTHING;
		}

//n_game_hwndprintf_literal( " %d ", p->hover );

		n_oc_path_fade( p );

	}


	if ( n_oc_is_desktop_selection() )
	{
		p->hover = N_ORANGECAT_NOTHING;
	}


//n_game_hwndprintf_literal( " %d %d ", p->hover, oc.view_drag_internal );
	if ( oc.view_drag_internal == N_ORANGECAT_DRAG_BREADCRUMB )
	{

		if ( ( p->press != N_ORANGECAT_NOTHING )&&( p->press != p->hover ) )
		{
			n_bmp_fade_go( &p->fade[ p->press ], oc_color.path_bg );
			p->press = N_ORANGECAT_NOTHING;
		}

		return;
	}


	if ( p->hover == N_ORANGECAT_NOTHING )
	{
//n_game_hwndprintf_literal( " Hover Released " );

		p->dnd_wait_onoff = n_false;


		if ( oc.is_external_dnd )
		{

			if ( oc.view_drag_external != N_ORANGECAT_DRAG_NEUTRAL )
			{
				n_oc_path_draw( p );
			}

		}

		if ( oc.view_hover != N_ORANGECAT_VIEW_HOVER_PATH )
		{
			if ( p->press != N_ORANGECAT_NOTHING )
			{
				n_bmp_fade_go( &p->fade[ p->press ], oc_color.path_bg );
				p->press = N_ORANGECAT_NOTHING;
			}
		}

		return;
	}


	// Phase 2 : Navigation

	static int dnd_index = N_ORANGECAT_NOTHING;


	if ( item.drag >= N_ORANGECAT_DRAG_LBUTTON )
	{
		n_oc_dnd_cursor();
	}


	if ( n_game_click_single( &oc.singleclick_l ) )
	{
//n_posix_debug_literal( " ! " );

		if ( item.drag == N_ORANGECAT_DRAG_NEUTRAL )
		{

			dnd_index = N_ORANGECAT_NOTHING;

			if ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_PATH )
			{

				oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
				n_oc_key_operation_onoff( n_false );

				p->press = p->hover;
				n_bmp_fade_go( &p->fade[ p->press ], oc_color.path_press );

				n_oc_event_btn_press();

			} else {
//n_posix_debug_literal( " ? " );

			}

		}

	} else
	if ( n_game_click_single( &oc.singleclick_m ) )
	{

		if ( item.drag == N_ORANGECAT_DRAG_NEUTRAL )
		{

			dnd_index = N_ORANGECAT_NOTHING;

			n_posix_char *name = n_oc_path_index2path_new( p, p->hover );

			n_oc_newwindow( name, n_true );

			n_string_path_free( name );

		}

	} else
	if ( oc.is_input )
	{
//n_game_hwndprintf_literal( " %d %d ", oc.is_input, item.drag );

		if ( item.drag == N_ORANGECAT_DRAG_UNKNOWN )
		{

			//

		} else
		if ( item.drag == N_ORANGECAT_DRAG_NEUTRAL )
		{
//n_game_hwndprintf_literal( " %d ", p->hover );
//n_game_hwndprintf_literal( " %d ", n_oc_is_desktop_selection() );

			if (
				( n_IDropTarget_is_running == n_false )
				&&
				( oc.is_external_dnd       == n_false )
			)
			{
//n_game_hwndprintf_literal( " %d ", oc.view_drag_internal );

//n_game_hwndprintf_literal( " %d : %d ", p->press, p->hover );

				// [!] : prevent press'n'run : see above code "oc.view_drag_internal"

				if ( ( p->press == N_ORANGECAT_NOTHING )&&( p->hover != N_ORANGECAT_NOTHING ) )
				{
					p->press = p->hover;
					n_bmp_fade_go( &p->fade[ p->press ], oc_color.path_press );

					//n_oc_event_btn_press();
				}

			} else {
//n_game_hwndprintf_literal( " external DnD " );

				// [!] : see n_oc_IDropTarget_dropeffect() @ oc_IDropTarget.c

			}

		} else
		if ( item.drag >= N_ORANGECAT_DRAG_LBUTTON )
		{
//n_game_hwndprintf_literal( "%d", item.drag );

			if ( n_oc_path_is_computer( p ) )
			{
//n_game_hwndprintf_literal( " Computer : %d ", item.drag );

				n_bmp_fade_go( &p->fade[ 0 ], oc_color.path_bg );
				n_oc_path_draw( p );

			} else {

				n_bool find_onoff = n_win_message_send( oc.view_hwnd, oc.msg_find_onoff, 0,0 );
				if ( ( item.find_onoff == n_false )&&( find_onoff == n_false ) )
				{
//n_game_hwndprintf_literal( " Wait " );
					if ( p->dnd_wait_onoff == n_false )
					{
						p->dnd_wait_onoff = n_true;
						p->dnd_wait_timer = n_posix_tickcount() + N_ORANGECAT_INTERVAL_LOCK;
					} else
					if ( p->dnd_wait_timer < n_posix_tickcount() )
					{
//n_game_hwndprintf_literal( " Hovered " );
						dnd_index = p->hover;
						n_bmp_fade_go( &p->fade[ p->hover ], oc_color.path_drop );
						n_oc_path_draw( p );
					}

				} else {
//n_game_hwndprintf_literal( " 2 " );
				}

			}

		}

	} else {
//n_game_hwndprintf_literal( " %d : %d ", p->hover, dnd_index );

		n_win_cursor_add( NULL, IDC_ARROW );

		if ( dnd_index == p->hover )
		{
//n_game_hwndprintf_literal( " %d : %d ", p->hover, dnd_index );

			n_posix_char *f = n_oc_item_multifocus_focus2path_new( &item );
			n_posix_char *t = n_oc_path_index2path_new( p, p->hover );

//n_posix_debug_literal( "%s\n%s", f, t );

			n_bool is_canceled = n_false;
			if ( n_false == n_oc_item_multifocus_dnd( f, t, item.drag, &is_canceled ) )
			{
				n_oc_event_itemsync();
			} else {
				n_project_dialog_info( game.hwnd, n_project_string_error );
			}

			n_string_path_free( f );
			n_string_path_free( t );


			// [Needed] : this position is important

			item.drag = N_ORANGECAT_DRAG_NEUTRAL;
			dnd_index = N_ORANGECAT_NOTHING;

			//n_oc_item_multifocus_off( &item );


			n_bmp_fade_go( &p->fade[ p->hover ], oc_color.path_hover );
			n_oc_path_draw( p );

		} else {
//n_posix_debug_literal( " ! " );

			// [!] : hovering without clicking

			if ( p->hover != N_ORANGECAT_NOTHING )
			{
				n_bmp_fade_go( &p->fade[ p->hover ], oc_color.path_hover );
				p->press = N_ORANGECAT_NOTHING;
			}

			// [Needed] : for drop to "Computer"

			item.drag = N_ORANGECAT_DRAG_NEUTRAL;

		}

		dnd_index = N_ORANGECAT_NOTHING;

	}


	return;
}

