// Nonnon DirectSound
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#ifndef _H_NONNON_WIN32_GAME_SOUND_DIRECTSOUND
#define _H_NONNON_WIN32_GAME_SOUND_DIRECTSOUND




#include "../../neutral/posix.c"
#include "../../neutral/wav.c"


#include <ole2.h>

#ifdef _MSC_VER
#pragma comment( lib, "ole32" )
#endif // #ifdef _MSC_VER




const GUID GUID_NULL               = { 0x00000000, 0x0000, 0x0000, { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 } };
const GUID CLSID_DirectSound       = { 0x47d4d946, 0x62e8, 0x11cf, { 0x93, 0xbc, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00 } };
const GUID IID_IDirectSoundBuffer  = { 0x279AFA85, 0x4981, 0x11CE, { 0xA5, 0x21, 0x00, 0x20, 0xAF, 0x0B, 0xE5, 0x60 } };
const GUID IID_IDirectSound        = { 0x279AFA83, 0x4981, 0x11CE, { 0xA5, 0x21, 0x00, 0x20, 0xAF, 0x0B, 0xE5, 0x60 } };
const GUID CLSID_DirectSound8      = { 0x3901cc3f, 0x84b5, 0x4fa4, { 0xba, 0x35, 0xaa, 0x81, 0x72, 0xb8, 0xa0, 0x9b } };
const GUID IID_IDirectSoundBuffer8 = { 0x6825a449, 0x7524, 0x4d82, { 0x92, 0x0f, 0x50, 0xe3, 0x6a, 0xb3, 0xab, 0x1e } };
const GUID IID_IDirectSound8       = { 0xC50A7E93, 0xF395, 0x4834, { 0x9E, 0xF6, 0x7F, 0xA9, 0x9D, 0xE5, 0x09, 0x66 } };
const GUID GUID_All_Objects        = { 0xaa114de5, 0xc262, 0x4169, { 0xa1, 0xc8, 0x23, 0xd6, 0x98, 0xcc, 0x73, 0xb5 } };
const GUID DSDEVID_DefaultPlayback = { 0xdef00000, 0x9c6d, 0x47ed, { 0xaa, 0xf1, 0x4d, 0xda, 0x8f, 0x2b, 0x5c, 0x03 } };




#ifdef _MSC_VER


#include <dsound.h>


#else  // #ifdef _MSC_VER


#ifndef __DSOUND_INCLUDED__


#define DSBCAPS_PRIMARYBUFFER        0x00000001
#define DSBCAPS_STATIC               0x00000002
#define DSBCAPS_LOCHARDWARE          0x00000004
#define DSBCAPS_LOCSOFTWARE          0x00000008
#define DSBCAPS_CTRL3D               0x00000010
#define DSBCAPS_CTRLFREQUENCY        0x00000020
#define DSBCAPS_CTRLPAN              0x00000040
#define DSBCAPS_CTRLVOLUME           0x00000080
#define DSBCAPS_CTRLPOSITIONNOTIFY   0x00000100
#define DSBCAPS_CTRLFX               0x00000200
#define DSBCAPS_STICKYFOCUS          0x00004000
#define DSBCAPS_GLOBALFOCUS          0x00008000
#define DSBCAPS_GETCURRENTPOSITION2  0x00010000
#define DSBCAPS_MUTE3DATMAXDISTANCE  0x00020000
#define DSBCAPS_LOCDEFER             0x00040000
#define DSBCAPS_TRUEPLAYPOSITION     0x00080000

#define DSSCL_NORMAL                 0x00000001
#define DSSCL_PRIORITY               0x00000002
#define DSSCL_EXCLUSIVE              0x00000003
#define DSSCL_WRITEPRIMARY           0x00000004

#define DSBLOCK_FROMWRITECURSOR      0x00000001
#define DSBLOCK_ENTIREBUFFER         0x00000002

#define DSBPLAY_LOOPING              0x00000001
#define DSBPLAY_LOCHARDWARE          0x00000002
#define DSBPLAY_LOCSOFTWARE          0x00000004
#define DSBPLAY_TERMINATEBY_TIME     0x00000008
#define DSBPLAY_TERMINATEBY_DISTANCE 0x000000010
#define DSBPLAY_TERMINATEBY_PRIORITY 0x000000020

#define DSBSIZE_MIN                  4
#define DSBSIZE_MAX                  0x0FFFFFFF

#define DSBVOLUME_MIN                -10000
#define DSBVOLUME_MAX                0




typedef struct _DSCAPS
{

	DWORD dwSize;
	DWORD dwFlags;
	DWORD dwMinSecondarySampleRate;
	DWORD dwMaxSecondarySampleRate;
	DWORD dwPrimaryBuffers;
	DWORD dwMaxHwMixingAllBuffers;
	DWORD dwMaxHwMixingStaticBuffers;
	DWORD dwMaxHwMixingStreamingBuffers;
	DWORD dwFreeHwMixingAllBuffers;
	DWORD dwFreeHwMixingStaticBuffers;
	DWORD dwFreeHwMixingStreamingBuffers;
	DWORD dwMaxHw3DAllBuffers;
	DWORD dwMaxHw3DStaticBuffers;
	DWORD dwMaxHw3DStreamingBuffers;
	DWORD dwFreeHw3DAllBuffers;
	DWORD dwFreeHw3DStaticBuffers;
	DWORD dwFreeHw3DStreamingBuffers;
	DWORD dwTotalHwMemBytes;
	DWORD dwFreeHwMemBytes;
	DWORD dwMaxContigFreeHwMemBytes;
	DWORD dwUnlockTransferRateHwBuffers;
	DWORD dwPlayCpuOverheadSwBuffers;
	DWORD dwReserved1;
	DWORD dwReserved2;

} DSCAPS;

typedef struct _DSBCAPS
{

	DWORD dwSize;
	DWORD dwFlags;
	DWORD dwBufferBytes;
	DWORD dwUnlockTransferRate;
	DWORD dwPlayCpuOverhead;

} DSBCAPS;

typedef struct _DSBUFFERDESC
{

	DWORD           dwSize;
	DWORD           dwFlags;
	DWORD           dwBufferBytes;
	DWORD           dwReserved;
	LPWAVEFORMATEX  lpwfxFormat;

	GUID            guid3DAlgorithm; // [Needed] : Win7 DX9

} DSBUFFERDESC;

typedef struct _DSEFFECTDESC
{

	DWORD     dwSize;
	DWORD     dwFlags;
	GUID      guidDSFXClass;
	DWORD_PTR dwReserved1;
	DWORD_PTR dwReserved2;

} DSEFFECTDESC;




#define INTERFACE IDirectSoundBuffer
DECLARE_INTERFACE_( IDirectSoundBuffer, IUnknown )
{

	STDMETHOD ( QueryInterface     ) ( THIS_ REFIID, VOID** ) PURE;
	STDMETHOD_( ULONG, AddRef      ) ( THIS ) PURE;
	STDMETHOD_( ULONG, Release     ) ( THIS ) PURE;

	STDMETHOD ( GetCaps            ) ( THIS_ DSBCAPS* ) PURE;
	STDMETHOD ( GetCurrentPosition ) ( THIS_ DWORD*, DWORD* ) PURE;
	STDMETHOD ( GetFormat          ) ( THIS_ WAVEFORMATEX*, DWORD, DWORD* ) PURE;
	STDMETHOD ( GetVolume          ) ( THIS_ LONG* ) PURE;
	STDMETHOD ( GetPan             ) ( THIS_ LONG* ) PURE;
	STDMETHOD ( GetFrequency       ) ( THIS_ DWORD* ) PURE;
	STDMETHOD ( GetStatus          ) ( THIS_ DWORD* ) PURE;
	STDMETHOD ( Initialize         ) ( THIS_ void*, DSBUFFERDESC* ) PURE;
	STDMETHOD ( Lock               ) ( THIS_ DWORD, DWORD, VOID**, DWORD*, VOID**, DWORD*, DWORD ) PURE;

	STDMETHOD ( Play               ) ( THIS_ DWORD, DWORD, DWORD ) PURE;
	STDMETHOD ( SetCurrentPosition ) ( THIS_ DWORD ) PURE;
	STDMETHOD ( SetFormat          ) ( THIS_ WAVEFORMATEX* ) PURE;
	STDMETHOD ( SetVolume          ) ( THIS_ LONG ) PURE;
	STDMETHOD ( SetPan             ) ( THIS_ LONG ) PURE;
	STDMETHOD ( SetFrequency       ) ( THIS_ DWORD ) PURE;
	STDMETHOD ( Stop               ) ( THIS ) PURE;
	STDMETHOD ( Unlock             ) ( THIS_ VOID*, DWORD, VOID*, DWORD ) PURE;
	STDMETHOD ( Restore            ) ( THIS ) PURE;

	// [!] : IDirectSoundBuffer8

	//STDMETHOD ( SetFX              ) ( THIS_ DWORD, DSEFFECTDESC*, DWORD* ) PURE;
	//STDMETHOD ( AcquireResources   ) ( THIS_ DWORD, DWORD, DWORD* ) PURE;
	//STDMETHOD ( GetObjectInPath    ) ( THIS_ REFGUID, DWORD, REFGUID, VOID** ) PURE;

};
#undef INTERFACE

#define IDirectSoundBuffer_QueryInterface(     p, a,b           ) (p)->lpVtbl->QueryInterface(     p, a,b           )
#define IDirectSoundBuffer_AddRef(             p                ) (p)->lpVtbl->AddRef(             p                )
#define IDirectSoundBuffer_Release(            p                ) (p)->lpVtbl->Release(            p                )
#define IDirectSoundBuffer_GetCaps(            p, a             ) (p)->lpVtbl->(                   p, a             )
#define IDirectSoundBuffer_GetCurrentPosition( p, a,b           ) (p)->lpVtbl->GetCurrentPosition( p, a,b           )
#define IDirectSoundBuffer_GetFormat(          p, a,b,c         ) (p)->lpVtbl->GetFormat(          p, a,b,c         )
#define IDirectSoundBuffer_GetVolume(          p, a             ) (p)->lpVtbl->GetVolume(          p, a             )
#define IDirectSoundBuffer_GetPan(             p, a             ) (p)->lpVtbl->GetPan(             p, a             )
#define IDirectSoundBuffer_GetFrequency(       p, a             ) (p)->lpVtbl->GetFrequency(       p, a             )
#define IDirectSoundBuffer_GetStatus(          p, a             ) (p)->lpVtbl->GetStatus(          p, a             )
#define IDirectSoundBuffer_Initialize(         p, a,b           ) (p)->lpVtbl->Initialize(         p, a,b           )
#define IDirectSoundBuffer_Lock(               p, a,b,c,d,e,f,g ) (p)->lpVtbl->Lock(               p, a,b,c,d,e,f,g )
#define IDirectSoundBuffer_Play(               p, a,b,c         ) (p)->lpVtbl->Play(               p, a,b,c         )
#define IDirectSoundBuffer_SetCurrentPosition( p, a             ) (p)->lpVtbl->SetCurrentPosition( p, a             )
#define IDirectSoundBuffer_SetFormat(          p, a             ) (p)->lpVtbl->SetFormat(          p, a             )
#define IDirectSoundBuffer_SetVolume(          p, a             ) (p)->lpVtbl->SetVolume(          p, a             )
#define IDirectSoundBuffer_SetPan(             p, a             ) (p)->lpVtbl->SetPan(             p, a             )
#define IDirectSoundBuffer_SetFrequency(       p, a             ) (p)->lpVtbl->SetFrequency(       p, a             )
#define IDirectSoundBuffer_Stop(               p                ) (p)->lpVtbl->Stop(               p                )
#define IDirectSoundBuffer_Unlock(             p, a,b,c,d       ) (p)->lpVtbl->Unlock(             p, a,b,c,d       )
#define IDirectSoundBuffer_Restore(            p                ) (p)->lpVtbl->Restore(            p                )

//#define IDirectSoundBuffer8_SetFX(              p, a,b,c         ) (p)->lpVtbl->SetFX(              p, a,b,c         )
//#define IDirectSoundBuffer8_AcquireResources(   p, a,b,c         ) (p)->lpVtbl->AcquireResources(   p, a,b,c         )
//#define IDirectSoundBuffer8_GetObjectInPath(    p, a,b,c,d       ) (p)->lpVtbl->GetObjectInPath(    p, a,b,c,d       )


#define INTERFACE IDirectSound
DECLARE_INTERFACE_( IDirectSound, IUnknown )
{

	STDMETHOD ( QueryInterface       ) ( THIS_ REFIID, VOID** ) PURE;
	STDMETHOD_( ULONG, AddRef        ) ( THIS ) PURE;
	STDMETHOD_( ULONG, Release       ) ( THIS ) PURE;

	STDMETHOD ( CreateSoundBuffer    ) ( THIS_ DSBUFFERDESC*, IDirectSoundBuffer**, IUnknown* ) PURE;
	STDMETHOD ( GetCaps              ) ( THIS_ DSCAPS* ) PURE;
	STDMETHOD ( DuplicateSoundBuffer ) ( THIS_ IDirectSoundBuffer*, IDirectSoundBuffer** ) PURE;
	STDMETHOD ( SetCooperativeLevel  ) ( THIS_ HWND, DWORD ) PURE;
	STDMETHOD ( Compact              ) ( THIS ) PURE;
	STDMETHOD ( GetSpeakerConfig     ) ( THIS_ DWORD* ) PURE;
	STDMETHOD ( SetSpeakerConfig     ) ( THIS_ DWORD ) PURE;
	STDMETHOD ( Initialize           ) ( THIS_ GUID* ) PURE;

	// [!] : IDirectSound8

	//STDMETHOD ( VerifyCertification  ) ( THIS_  DWORD* ) PURE;

};
#undef INTERFACE

#define IDirectSound_QueryInterface(       p, a,b   ) (p)->lpVtbl->QueryInterface(       p, a,b   )
#define IDirectSound_AddRef(               p        ) (p)->lpVtbl->AddRef(               p        )
#define IDirectSound_Release(              p        ) (p)->lpVtbl->Release(              p        )
#define IDirectSound_CreateSoundBuffer(    p, a,b,c ) (p)->lpVtbl->CreateSoundBuffer(    p, a,b,c )
#define IDirectSound_GetCaps(              p, a     ) (p)->lpVtbl->GetCaps(              p, a     )
#define IDirectSound_DuplicateSoundBuffer( p, a,b   ) (p)->lpVtbl->DuplicateSoundBuffer( p, a,b   )
#define IDirectSound_SetCooperativeLevel(  p, a,b   ) (p)->lpVtbl->SetCooperativeLevel(  p, a,b   )
#define IDirectSound_Compact(              p        ) (p)->lpVtbl->Compact(              p        )
#define IDirectSound_GetSpeakerConfig(     p, a     ) (p)->lpVtbl->GetSpeakerConfig(     p, a     )
#define IDirectSound_SetSpeakerConfig(     p, a     ) (p)->lpVtbl->SetSpeakerConfig(     p, a     )
#define IDirectSound_Initialize(           p, a     ) (p)->lpVtbl->Initialize(           p, a     )

//#define IDirectSound8_VerifyCertification(  p, a     ) (p)->lpVtbl->VerifyCertification(  p, a     )


#endif // #ifndef __DSOUND_INCLUDED__


#endif // #ifdef _MSC_VER




typedef struct {

	IDirectSound       *ds;
	IDirectSoundBuffer *dsb;

	DWORD                dw1, dw2;

} n_directsound;




#define n_directsound_zero( p ) n_memory_zero( p, sizeof( n_directsound ) )

n_posix_bool
n_directsound_exit( n_directsound *p )
{

	// [!] : holding p->ds is needed to playback

	if ( p->dsb != NULL )
	{
		IDirectSoundBuffer_Stop   ( p->dsb );
		IDirectSoundBuffer_Release( p->dsb );
	}

	if ( p->ds != NULL )
	{
		IDirectSound_Release( p->ds );
	}

	n_directsound_zero( p );


	CoUninitialize();


	return n_posix_false;
}

n_posix_bool
n_directsound_init( n_directsound *p, HWND hwnd, n_wav *wav )
{

	// [!] : call this after ShowWindow() at WM_CREATE is done


	// [!] : hwnd is always nedded else no sound will be output

	if ( hwnd == NULL ) { return n_posix_true; }


	// [!] : Win95a : CoInitializeEx() is not exist

	CoInitialize( NULL );


//CoInitializeEx( NULL, 0 );

/*
	HMODULE hmod = LoadLibrary( n_posix_literal( "ole32.dll" ) );
	FARPROC func = GetProcAddress( hmod, "CoInitializeEx" );

	if ( hmod == NULL ) { return n_posix_true; }
	if ( func != NULL )
	{
//n_posix_debug_literal( "CoInitializeEx() is found" );
		func( NULL, 0 );
	}

	FreeLibrary( hmod );

	if ( func == NULL ) { return n_posix_true; }
*/

	// Device

	CoCreateInstance
	(
		&CLSID_DirectSound,
		NULL, 
		CLSCTX_INPROC_SERVER,
		&IID_IDirectSound,
		(LPVOID*) &p->ds
	);
	if ( p->ds == NULL )
	{
//n_posix_debug_literal( " IID_IDirectSound " );

		return n_posix_true;
	}
	IDirectSound_Initialize( p->ds, NULL );
	IDirectSound_SetCooperativeLevel( p->ds, hwnd, DSSCL_PRIORITY );


	// Buffer

	// [x] : error : DSBCAPS_LOCHARDWARE

	// [Needed] : DSBCAPS_LOCDEFER | DSBCAPS_GLOBALFOCUS
	//
	//	DSBCAPS_LOCDEFER    : important for playback
	//	DSBCAPS_GLOBALFOCUS : sound will be cut while WM_CREATE

	WAVEFORMATEX fmt   = N_WAV_FMT( wav );
	int          caps1 = DSBCAPS_LOCDEFER | DSBCAPS_GLOBALFOCUS;
	int          caps2 = DSBCAPS_CTRLPAN | DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLFREQUENCY;
	int          byte  = N_WAV_SIZE( wav );
	DSBUFFERDESC bd    = { sizeof( DSBUFFERDESC ), caps1 | caps2, byte, 0, &fmt, GUID_NULL };

	IDirectSound_CreateSoundBuffer( p->ds, &bd, (void*) &p->dsb, NULL );

	if ( p->dsb == NULL )
	{
//n_posix_debug_literal( " IDirectSound_CreateSoundBuffer() " );

		n_directsound_exit( p );

		return n_posix_true;
	}


	VOID  *buf = NULL;
	DWORD  len = 0;

	IDirectSoundBuffer_Lock  ( p->dsb, 0,0, &buf,&len, NULL,NULL, DSBLOCK_ENTIREBUFFER );
//n_posix_debug_literal( "%x : %d %d", buf,len, byte );

	n_memory_copy( N_WAV_PTR( wav ), buf,len );

	IDirectSoundBuffer_Unlock( p->dsb, buf,len, NULL,0 );


	// Misc

	IDirectSoundBuffer_SetVolume( p->dsb, 0 );


	return n_posix_false;
}

n_posix_bool
n_directsound_loop( n_directsound *p )
{

	if ( p->dsb == NULL ) { return n_posix_true; }

	IDirectSoundBuffer_SetCurrentPosition( p->dsb, 0 );
	IDirectSoundBuffer_Play( p->dsb, 0, 0xffffffff, 0 );


	return n_posix_false;
}

n_posix_bool
n_directsound_stop( n_directsound *p )
{

	if ( p->dsb == NULL ) { return n_posix_true; }

	IDirectSoundBuffer_Stop( p->dsb );


	return n_posix_false;
}

n_posix_bool
n_directsound_pause( n_directsound *p )
{

	if ( p->dsb == NULL ) { return n_posix_true; }

	IDirectSoundBuffer_GetCurrentPosition( p->dsb, &p->dw1, &p->dw2 );
	IDirectSoundBuffer_Stop( p->dsb );


	return n_posix_false;
}

n_posix_bool
n_directsound_resume( n_directsound *p )
{

	if ( p->dsb == NULL ) { return n_posix_true; }

	IDirectSoundBuffer_SetCurrentPosition( p->dsb, p->dw1 );
	IDirectSoundBuffer_Play( p->dsb, 0, 0xffffffff, 0 );


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_GAME_SOUND_DIRECTSOUND

