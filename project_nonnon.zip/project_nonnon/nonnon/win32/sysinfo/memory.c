// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_MEMORY
#define _H_NONNON_WIN32_SYSINFO_MEMORY




#include "./version.c"




int
n_sysinfo_memory( u32 *total, u32 *used, u32 *rest )
{

	int percent = 0;


	HMODULE hmod = LoadLibrary( n_posix_literal( "kernel32.dll" ) );
	if ( hmod == NULL ) { return percent; }


	double t = 0;
	double u = 0;
	double r = 0;


	FARPROC func = GetProcAddress( hmod, "GlobalMemoryStatusEx" );
	if ( func != NULL )
	{

		MEMORYSTATUSEX memstat;
		memstat.dwLength = sizeof( MEMORYSTATUSEX );

		func( &memstat );

		t = (double) memstat.ullTotalPhys;
		u = (double) memstat.ullTotalPhys - memstat.ullAvailPhys;
		r = (double) memstat.ullAvailPhys;

		percent = (int) memstat.dwMemoryLoad;

	} else {

		func = GetProcAddress( hmod, "GlobalMemoryStatus" );
		if ( func != NULL )
		{

			MEMORYSTATUS memstat;

			func( &memstat );

			t = (double) memstat.dwTotalPhys;
			u = (double) memstat.dwTotalPhys - memstat.dwAvailPhys;
			r = (double) memstat.dwAvailPhys;

			percent = 100 * ( u / t );

		}

	}


	if ( total != NULL ) { (*total) = (u32) t; }
	if ( used  != NULL ) { (*used ) = (u32) u; }
	if ( rest  != NULL ) { (*rest ) = (u32) r; }


	FreeLibrary( hmod );


	return percent;
}


#endif // _H_NONNON_WIN32_SYSINFO_MEMORY

