// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_RESOURCE
#define _H_NONNON_WIN32_RESOURCE




#include "../neutral/posix.c"




n_posix_bool
n_resource_load
(
	const n_posix_char *name,
	const n_posix_char *sect,
	              void *rc,
	              s64  *rc_byte
)
{

	HINSTANCE hinst = GetModuleHandle( NULL );


	HRSRC hrc = FindResource( hinst, name, sect );
	if ( hrc == NULL ) { return n_posix_true; }


	HGLOBAL hglobal = LoadResource( hinst, hrc );
	if ( hglobal == NULL )
	{

		CloseHandle( hrc );

		return n_posix_true;
	}


	u8  *ptr      = LockResource( hglobal );
	s64  ptr_byte = SizeofResource( hinst, hrc );

	if ( rc != NULL )
	{
		n_memory_copy( ptr, rc, ptr_byte );
	}

	if ( rc_byte != NULL )
	{
		(*rc_byte) = ptr_byte;
	}

	// [!] : -Wall says "no effect"
	//UnlockResource( hglobal );


	FreeResource( hglobal );


	//CloseHandle( hrc );


	return n_posix_false;
}

#define n_resource_save_literal( a,b,c ) n_resource_save( n_posix_literal( a ), n_posix_literal( b ), n_posix_literal( c ) )

n_posix_bool
n_resource_save
(
	const n_posix_char *name,
	const n_posix_char *sect,
	const n_posix_char *fname
)
{

	s64 byte;


	n_posix_bool ret = n_resource_load( name, sect, NULL, &byte );

//n_posix_debug( "%lu : %lu", ret, byte );

	if ( ret ) { return n_posix_true; }


	FILE *fp = n_posix_fopen_write( fname );
	if ( fp == NULL ) { return n_posix_true; }


	u8 *ptr = n_memory_new_closed( byte );

	n_resource_load( name, sect, ptr, NULL );
	n_posix_fwrite( ptr, byte, 1, fp );

	n_memory_free_closed( ptr );


	n_posix_fclose( fp );


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_RESOURCE

