// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File


// [!] : init() and exit() are not used
//
//	optimization is implemented in n_win_txtbox_draw(), draw_singleline() now



/*
void
n_win_txtbox_refresh_optimized_init( n_win_txtbox *p )
{
	return;
}

void
n_win_txtbox_refresh_optimized_exit( n_win_txtbox *p )
{
	return;
}
*/

