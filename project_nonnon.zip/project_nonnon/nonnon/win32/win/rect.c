// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism]
//
//	[ Coordinate Handling ]
//
//	absolute postion on desktop
//	range
//
//	+ use n_win_location()/_position()/_size() for size based approach


// [!] : Similar Functions
//	
//	n_win_rect_zero()       : SetRectEmpty( &r );
//	n_win_rect_set_simple() : SetRect( &r, x1, y1, x2, y2 );
//	n_win_rect_resize()     : InflateRect( &r, dx, dy );




#ifndef _H_NONNON_WIN32_WIN_RECT
#define _H_NONNON_WIN32_WIN_RECT




#include "./_debug.c"




void
n_win_rect_debug( RECT *r )
{

	if ( r == NULL ) { return; }

	n_posix_debug_literal( "%d %d %d %d", r->left, r->top, r->right, r->bottom );


	return;
}

RECT
n_win_rect_zero( RECT *r )
{

	// [!] : SetRectEmpty( r ); is a similar function


	// [!] : don't return "r" directly

	RECT ret = { 0,0,0,0 };

	if ( r != NULL ) { (*r) = ret; }


	return ret;
}

#define n_win_rect_zero( r ) n_win_rect_set_simple( r, 0, 0, 0, 0 )

#define n_win_rect_set( r, x1, y1, x2, y2 ) n_win_rect_set_simple( r, x1, y1, (x1) + (x2), (y1) + (y2) )

RECT
n_win_rect_set_simple( RECT *r, s32 x1, s32 y1, s32 x2, s32 y2 )
{

	// [!] : don't return "r" directly

	RECT ret = { x1, y1, x2, y2 };

	if ( r != NULL ) { (*r) = ret; }


	return ret;
}

#define n_win_rect_move(   r, dx, dy ) n_win_rect_tweak( r,   dx  ,   dy  , dx, dy )
#define n_win_rect_resize( r, dx, dy ) n_win_rect_tweak( r,-( dx ),-( dy ), dx, dy )

RECT
n_win_rect_tweak( RECT *r, s32 dfx, s32 dfy, s32 dtx, s32 dty )
{

	// [!] : don't return "r" directly

	RECT ret = { 0,0,0,0 };

	if ( r != NULL ) { ret = (*r); }

	ret.left   += dfx;
	ret.top    += dfy;
	ret.right  += dtx;
	ret.bottom += dty;

	if ( r != NULL ) { (*r) = ret; }


	return ret;
}

RECT
n_win_rect_min( RECT *r, s32 x, s32 y, s32 sx, s32 sy )
{

	// [!] : don't return "r" directly

	RECT ret = { 0,0,0,0 };

	if ( r != NULL ) { ret = (*r); }

	ret.left   = n_posix_min_s32( ret.left,    x );
	ret.top    = n_posix_min_s32( ret.top,     y );
	ret.right  = n_posix_min_s32( ret.right,  sx );
	ret.bottom = n_posix_min_s32( ret.bottom, sy );

	if ( r != NULL ) { (*r) = ret; }


	return ret;
}

RECT
n_win_rect_max( RECT *r, s32 x, s32 y, s32 sx, s32 sy )
{

	// [!] : don't return "r" directly

	RECT ret = { 0,0,0,0 };

	if ( r != NULL ) { ret = (*r); }

	ret.left   = n_posix_max_s32( ret.left,    x );
	ret.top    = n_posix_max_s32( ret.top,     y );
	ret.right  = n_posix_max_s32( ret.right,  sx );
	ret.bottom = n_posix_max_s32( ret.bottom, sy );

	if ( r != NULL ) { (*r) = ret; }


	return ret;
}

void
n_win_rect_expand_range( RECT *r, s32 *fx, s32 *fy, s32 *tx, s32 *ty )
{

	RECT r_zero = { 0,0,0,0 };
	if ( r == NULL ) { r = &r_zero; }

	if ( fx != NULL ) { (*fx) = r->left;   }
	if ( fy != NULL ) { (*fy) = r->top;    }
	if ( tx != NULL ) { (*tx) = r->right;  }
	if ( ty != NULL ) { (*ty) = r->bottom; }


	return;
}

void
n_win_rect_expand_size( RECT *r, s32 *x, s32 *y, s32 *sx, s32 *sy )
{

	RECT r_zero = { 0,0,0,0 };
	if ( r == NULL ) { r = &r_zero; }

	if (  x != NULL ) { (* x) = r->left;             }
	if (  y != NULL ) { (* y) = r->top;              }
	if ( sx != NULL ) { (*sx) = r->right  - r->left; }
	if ( sy != NULL ) { (*sy) = r->bottom - r->top;  }


	return;
}

n_posix_bool
n_win_rect_collision( RECT *r_f, RECT *r_t )
{

	s32 f_fx, f_fy, f_tx, f_ty;
	s32 t_fx, t_fy, t_tx, t_ty;

	n_win_rect_expand_range( r_f, &f_fx, &f_fy, &f_tx, &f_ty );
	n_win_rect_expand_range( r_t, &t_fx, &t_fy, &t_tx, &t_ty );


	if (
		(
			( ( f_fx >= t_fx )&&( f_fx < t_tx ) )
			||
			( ( f_tx >= t_fx )&&( f_tx < t_tx ) )
		)
		&&
		(
			( ( f_fy >= t_fy )&&( f_fy < t_ty ) )
			||
			( ( f_ty >= t_fy )&&( f_ty < t_ty ) )
		)
	)
	{
		return n_posix_true;
	}


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_WIN_RECT

