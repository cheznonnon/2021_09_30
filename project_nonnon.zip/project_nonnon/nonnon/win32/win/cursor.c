// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_CURSOR
#define _H_NONNON_WIN32_WIN_CURSOR




#include "./_debug.c"




HWND
n_win_cursor2hwnd( void )
{

	POINT p;


	GetCursorPos( &p );


	return WindowFromPoint( p );
}

HWND
n_win_cursor2hwnd_relative( HWND hwnd_parent )
{

	// [!] : if this module is not working, use n_win_is_hovered() instead

	POINT p;


	GetCursorPos( &p );
	ScreenToClient( hwnd_parent, &p );


	return ChildWindowFromPoint( hwnd_parent, p );
}

#define n_win_cursor_position( x, y ) n_win_cursor_position_relative( NULL, x, y )

void
n_win_cursor_position_relative( HWND hwnd_parent, s32 *x, s32 *y )
{

	POINT p; GetCursorPos( &p );

	ScreenToClient( hwnd_parent, &p );

	if ( x != NULL ) { (*x) = p.x; }
	if ( y != NULL ) { (*y) = p.y; }


	return;
}

#define n_win_cursor_exit( hcursor ) DestroyCursor( hcursor )

#define n_win_cursor_init_literal( name ) n_win_cursor_init( n_posix_literal( name ) )

HCURSOR
n_win_cursor_init( const n_posix_char *name )
{

	HINSTANCE hinst = GetModuleHandle( NULL );


	HCURSOR hcursor;


	// Phase 1 : load from IDC_*

	hcursor = LoadCursor( NULL, name );
	if ( hcursor != NULL ) { return hcursor; }


	// Phase 2 : load from resources

	hcursor = LoadCursor( hinst, name );
	if ( hcursor != NULL ) { return hcursor; }


	// Phase 3 : load from file : DestroyCursor() is needed

	hcursor = LoadCursorFromFile( name );
	if ( hcursor != NULL ) { return hcursor; }


	return NULL;
}

#ifdef _WIN64
#define n_win_cursor_get( hwnd ) (HCURSOR) GetClassLongPtr( hwnd, GCLP_HCURSOR )
#else  // #ifdef _WIN64
#define n_win_cursor_get( hwnd ) (HCURSOR) GetClassLong(    hwnd, GCL_HCURSOR  )
#endif // #ifdef _WIN64

void
n_win_cursor_set( HWND hwnd, HCURSOR hcur )
{

	// [Mechanism]
	//
	//                     |   other hwnd | auto-refresh |
	//	SetCursor()    |       x      |      o       | for temporary use
	//	SetClassLong() |       o      |      x       | for setting default

	// [!] : if it seems to be not working, call twice one for hwnd NULL, another set hwnd non-NULL


	if ( hwnd == NULL )
	{
		SetCursor( hcur );
	} else {
#ifdef _WIN64
		SetClassLongPtr( hwnd, GCLP_HCURSOR, (LONG_PTR) hcur );
#else  // #ifdef _WIN64
		SetClassLong   ( hwnd, GCL_HCURSOR , (LONG    ) hcur );
#endif // #ifdef _WIN64
	}


	return;
}

#define n_win_cursor_add(         h, s ) n_win_cursor_set( h, n_win_cursor_init(         s ) )
#define n_win_cursor_add_literal( h, s ) n_win_cursor_set( h, n_win_cursor_init_literal( s ) )
#define n_win_cursor_del(         h    ) n_win_cursor_exit( n_win_cursor_get( h ) )


#endif // _H_NONNON_WIN32_WIN_CURSOR

