// Nonnon COM : HTMLWindowEvents
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [x] : this sink is useless




#ifndef _H_NONNON_WIN32_COM_HTMLWINDOWEVENTS
#define _H_NONNON_WIN32_COM_HTMLWINDOWEVENTS




#include <olectl.h>
//#include <mshtmdid.h>




// [Patch] : missing symbols

// mshtmdid.h

#define DISPID_HTMLWINDOWEVENTS_ONLOAD         DISPID_EVMETH_ONLOAD
#define DISPID_HTMLWINDOWEVENTS_ONUNLOAD       DISPID_EVMETH_ONUNLOAD
#define DISPID_HTMLWINDOWEVENTS_ONHELP         DISPID_EVMETH_ONHELP
#define DISPID_HTMLWINDOWEVENTS_ONFOCUS        DISPID_EVMETH_ONFOCUS
#define DISPID_HTMLWINDOWEVENTS_ONBLUR         DISPID_EVMETH_ONBLUR
#define DISPID_HTMLWINDOWEVENTS_ONERROR        DISPID_EVMETH_ONERROR
#define DISPID_HTMLWINDOWEVENTS_ONRESIZE       DISPID_EVMETH_ONRESIZE
#define DISPID_HTMLWINDOWEVENTS_ONSCROLL       DISPID_EVMETH_ONSCROLL
#define DISPID_HTMLWINDOWEVENTS_ONBEFOREUNLOAD DISPID_EVMETH_ONBEFOREUNLOAD
#define DISPID_HTMLWINDOWEVENTS_ONBEFOREPRINT  DISPID_EVMETH_ONBEFOREPRINT
#define DISPID_HTMLWINDOWEVENTS_ONAFTERPRINT   DISPID_EVMETH_ONAFTERPRINT




HRESULT __stdcall
n_HTMLWindowEvents_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID w = n_com_guid( n_guid_DIID_HTMLWindowEvents );

	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &w ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

HRESULT __stdcall
n_HTMLWindowEvents_IDispatch_Invoke
(
	void         *_this,
	DISPID        dispIdMember,
	REFIID        riid,
	LCID          lcid,
	WORD          wFlags,
	DISPPARAMS   *pDispParams,
	VARIANT      *pVarResult,
	EXCEPINFO    *pExcepInfo,
	unsigned int *puArgErr
)
{

	switch( dispIdMember ) {


	case DISPID_HTMLWINDOWEVENTS_ONLOAD :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONLOAD " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONUNLOAD :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONUNLOAD " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONHELP :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONHELP " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONFOCUS :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONFOCUS " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONBLUR :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONBLUR " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONERROR :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONERROR " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONRESIZE :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONRESIZE " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONSCROLL :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONSCROLL " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONBEFOREUNLOAD :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONBEFOREUNLOAD " );

		// [!] : don't touch : confirmation dialog will appear

	break;

	case DISPID_HTMLWINDOWEVENTS_ONBEFOREPRINT :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONBEFOREPRINT " );
	break;

	case DISPID_HTMLWINDOWEVENTS_ONAFTERPRINT :
N_COM_DEBUG_LISTBOX_SET_A( " HTMLWindowEvents DISPID_HTMLWINDOWEVENTS_ONAFTERPRINT " );
	break;


	default :
	{
char str[ 100 ];
sprintf( str, " HTMLWindowEvents : DISP_E_MEMBERNOTFOUND : %08x : %d ", (int) dispIdMember, (int) dispIdMember );
N_COM_DEBUG_LISTBOX_SET_A( str );

		return DISP_E_MEMBERNOTFOUND;

	}
	break;


	} // switch


	return S_OK;
}




const void *n_HTMLWindowEvents_Vtbl[] = {

	n_HTMLWindowEvents_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,
	n_com_IDispatch_GetTypeInfoCount,
	n_com_IDispatch_GetTypeInfo,
	n_com_IDispatch_GetIDsOfNames,
	n_HTMLWindowEvents_IDispatch_Invoke

};


IDispatch n_HTMLWindowEvents_instance = { (void*) n_HTMLWindowEvents_Vtbl };




#endif // _H_NONNON_WIN32_COM_HTMLWINDOWEVENTS

